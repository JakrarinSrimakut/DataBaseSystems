--Give the different jobLevels that appear for active IRSagents.
--The jobLevels in your result should appear in decreasing numerical order.
--SELECT * FROM IRSagents;

SELECT joblevel
FROM IRSagents
ORDER BY joblevel DESC;
