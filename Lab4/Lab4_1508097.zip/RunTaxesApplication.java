import java.sql.*;
import java.io.*;
import java.util.*;

/**
 * A class that connects to PostgreSQL and disconnects.
 * You will need to change your credentials below, to match the usename and password of your account
 * in the PostgreSQL server.
 * The name of your database in the server is the same as your username.
 * You are asked to include code that tests the methods of the TaxesApplication class
 * in a similar manner to the sample RunStoresApplication.java program.
*/


public class RunTaxesApplication
{
    public static void main(String[] args) {
    	
    	Connection connection = null;
    	try {
    	    //Register the driver
    		Class.forName("org.postgresql.Driver"); 
    	    // Make the connection.
            // You will need to fill in your real username
            // and password for your Postgres account in the arguments of the
            // getConnection method below.
            connection = DriverManager.getConnection(
                                                     "jdbc:postgresql://cmps180-db.lt.ucsc.edu/jsrimaku",
                                                     "username",
                                                     "password");
            
            if (connection != null)
                System.out.println("Connected to the database!");

            /* Include your code below to test the methods of the TaxesApplication class
             * The sample code in RunStoresApplication.java should be useful.
             * That code tests other methods for a different database schema.
             * Your code below: */
 
///////////////////TaxesApplication//////////////////////
          	TaxesApplication taxApp = new TaxesApplication(connection);
		int numberOfDelinquents = 2;
		
		//list to store return list
		List<Integer> delTaxIdList = taxApp.getIRSagentsWithManyDelinquents(numberOfDelinquents);
		//return list
		System.out.println("IRSagents with at least " +
					numberOfDelinquents + " delinquents "); 
		//System.out.println(delTaxIdList.size());
		//for loop list printing each taxpayerId of delinquent
		for(Integer delTaxId : delTaxIdList)
			System.out.println(delTaxId);
		/*
		 * *Output of getIRSagentsWithManyDelinquents
		 * *when the parameter numberOfDelinquents is 2.
		 * output here
		 * 
		 * IRSagents with at least 2 delinquents 
		 * 136
		 * 133
		 * 110
		 *
		 * */
///////////////////increaseTaxOwed//////////////////////
		String addr = "843 Ante Ave";
		float inc = 125.00f;
		System.out.println("\nUpdate " + addr + " totalTaxedOwed by " + inc);

		int incTaxPayer= taxApp.increaseTaxOwed(addr,inc);
		System.out.println("Number of increasedTaxOwed taxpayer " + incTaxPayer + "\n");
		/*
		* *Output of increaseTaxOwed when the increment is 125.00
		* output here
		*
		* Update 843 Ante Ave totalTaxedOwed by 125.0
		*
		* Number of increasedTaxOwed taxpayer 3
		*
		* */
///////////////////setAgentForSomeDelinquents//////////////////////

String agentID = "P3E4RR";

            int count = 1;
            int numberOfDelinquent = taxApp.setAgentForSomeDelinquents(agentID, count);

            System.out.println("Amount of altered rows when count is 1 and agentID = P3E4RR: " + numberOfDelinquent);
            agentID = "31AD01";

            count = 4;

            numberOfDelinquent = taxApp.setAgentForSomeDelinquents(agentID, count);

            System.out.println("Amount of altered rows when count is 4 and agentID= 31AD01: " + numberOfDelinquent);
/*
 * *Output of increaseTaxOwed when the increment is 125.00
 * output here
 *
 *
 *Amount of altered rows when count is 1 and agentID = P3E4RR: 0
 *Amount of altered rows when count is 4 and agentID= 31AD01: 0
 *
 *
 *
 * */



	    /*******************
            * Your code ends here */
            
    	}
    	catch (SQLException | ClassNotFoundException e) {
    		System.out.println("Error while connecting to database: " + e);
    		e.printStackTrace();
    	}
    	finally {
    		if (connection != null) {
    			// Closing Connection
    			try {
					connection.close();
				} catch (SQLException e) {
					System.out.println("Failed to close connection: " + e);
					e.printStackTrace();
				}
    		}
    	}
    }
}
