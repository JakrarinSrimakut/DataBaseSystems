CREATE INDEX LookUpReturns
ON TaxReturns (kind,dateFiled);
